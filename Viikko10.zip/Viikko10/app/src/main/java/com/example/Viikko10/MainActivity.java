package com.example.Viikko10;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Spinner;
import com.example.viikko10.R;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    private EditText txtF;
    private EditText txtL;
    private EditText txtEA;
    private List<ImageItem> imageItemList;
    private int selectedImage;
    private LinearLayout degreeCheckboxList; // Uusi
    private List<CheckBox> degreeCheckBoxes; // uusi

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtF = findViewById(R.id.textFirstname);
        txtL = findViewById(R.id.textLastname);
        txtEA = findViewById(R.id.inputEmail);

        Spinner imageSpinner = findViewById(R.id.image_spinner);
        initImageItemList();
        ImageSpinnerAdapter adapter = new ImageSpinnerAdapter(this, R.layout.spinner_view, imageItemList);
        imageSpinner.setAdapter(adapter);
        imageSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                ImageItem selectedItem = (ImageItem) adapterView.getItemAtPosition(position);
                selectedImage = selectedItem.getImageResource();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }

        });

        degreeCheckboxList = findViewById(R.id.degreeCheckBoxList);
        degreeCheckBoxes = new ArrayList<>();
        populateDegreeCheckBoxes();


    }
    public void addUser(View view) {
        String firstName = String.valueOf(txtF.getText());
        String lastName = String.valueOf(txtL.getText());
        String emailAddress = String.valueOf(txtEA.getText());
        String degreeProgram = null;



        RadioGroup rgDegreeProgram = findViewById(R.id.degreeProgram);
        switch (rgDegreeProgram.getCheckedRadioButtonId()) {
            case R.id.radioButtonLate:
                degreeProgram = "Laskennallinen tekniikka";
                break;
            case R.id.radioButtonTuta:
                degreeProgram = "Tuotantotalous";
                break;
            case R.id.radioButtonTite:
                degreeProgram = "Tietotekniikka";
                break;
        }
        User newUser = new User(firstName, lastName, emailAddress, degreeProgram, selectedImage);
        UserStorage.getInstance().addUser(newUser);
    }
    public void switchToListUsers(View view) {
        Intent intent = new Intent(this, ListUsersActivity.class);
        startActivity(intent);
    }
    private void initImageItemList() {
        imageItemList = new ArrayList<>();
        imageItemList.add(new ImageItem(R.drawable.happy, "Happy"));
        imageItemList.add(new ImageItem(R.drawable.neutral, "Neutral"));
        imageItemList.add(new ImageItem(R.drawable.sad, "Sad"));
    }

    private void populateDegreeCheckBoxes() {
        String[] degreeChoices = getResources().getStringArray(R.array.degree_choices);

        for (String degree : degreeChoices) {
            CheckBox checkBox = new CheckBox(this);
            checkBox.setText(degree);
            degreeCheckboxList.addView(checkBox);
            degreeCheckBoxes.add(checkBox);
        }
    }

    private List<String> getSelectedDegree() {
        List<String> selectedDegrees = new ArrayList<>();

        for (CheckBox checkBox : degreeCheckBoxes) {
            if (checkBox.isChecked()) {
                selectedDegrees.add(checkBox.getText().toString());
            }
        }
        return selectedDegrees;
    }
}