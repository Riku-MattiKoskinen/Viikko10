package com.example.Viikko10;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.viikko10.R;

public class UserListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_users);
    }
}